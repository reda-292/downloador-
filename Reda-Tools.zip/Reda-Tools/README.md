# Reda Tools — Offline Translator + YouTube Downloader (macOS)

Two small apps that open in your browser but run 100% on your Mac.

| App | What it does | Engine |
|---|---|---|
| **Translator** | English ⇄ Arabic (add 40+ more languages). Translates with **no internet**. | Argos Translate (local AI models) |
| **YouTube Downloader** | Paste a link → **MP4** video (360p–4K) or **MP3** audio (128–320 kbps). Playlists supported. | yt-dlp + ffmpeg |

## Setup (once, needs internet, ~3–6 min, ~1.5 GB)

1. Put the `Reda-Tools` folder somewhere permanent (e.g. `Documents`).
2. Open **Terminal**, then run:
   ```bash
   cd ~/Documents/Reda-Tools
   chmod +x *.command
   ./setup.command
   ```
   It installs a private Python 3.12 inside this folder (`.venv`) — it does not touch your system.
   It also downloads the English⇄Arabic models and ffmpeg.

## Use

- Double-click **`Translator.command`** → opens http://127.0.0.1:8765
- Double-click **`YouTube Downloader.command`** → opens http://127.0.0.1:8766

Keep the Terminal window open while using an app; close it (or Ctrl+C) to quit.

> First double-click: macOS may say it "can't be opened". Right-click the file → **Open** → **Open**. Only needed once.

## Translator tips
- **Auto-detect** recognises Arabic vs English automatically and flips direction for you.
- **⌘ + Enter** translates immediately (it also translates as you type).
- **Languages** button → download more languages (needs internet once each), or remove ones you don't use.
- Extra language from Terminal: `.venv/bin/python translator/setup_models.py en fr`

## Downloader tips
- Paste several links separated by spaces to queue them all.
- **1080p** is the default: H.264 + AAC, plays everywhere (QuickTime, iPhone, WhatsApp).
  **Max quality** can be 4K but may need VLC/IINA to play.
- Files go to `~/Downloads/YouTube Downloads` — change with **Change…**.
- If YouTube downloads start failing: close and reopen the app (it auto-updates yt-dlp on launch).
- Only download content you own or have permission to save.

## Folder layout
```
Reda-Tools/
├── setup.command                 one-time installer
├── Translator.command            start translator
├── YouTube Downloader.command    start downloader
├── translator/  app.py · index.html · setup_models.py · offline_patch.py
└── downloader/  app.py · index.html · setup_ffmpeg.py
```

## Uninstall
Delete the `Reda-Tools` folder. Models live in `~/.local/share/argos-translate` (delete that too to free space).
