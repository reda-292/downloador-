#!/usr/bin/env python3
"""Offline Translator - a small local web app powered by Argos Translate.

Runs at http://127.0.0.1:8765 . Translation happens 100% on this computer.
Internet is only needed once, to download a language model.
"""
import json
import os
import re
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
PORT = int(os.environ.get("TRANSLATOR_PORT", "8765"))
URL = f"http://127.0.0.1:{PORT}"

# Quiet, CPU-only, deterministic.
os.environ.setdefault("ARGOS_DEVICE_TYPE", "cpu")

sys.path.insert(0, str(HERE))
import offline_patch  # noqa: E402,F401  (must load before argostranslate translates)
import argostranslate.package as argos_pkg  # noqa: E402
import argostranslate.translate as argos_tr  # noqa: E402

LOCK = threading.Lock()  # one model operation at a time

# ---------------------------------------------------------------- helpers

# Script ranges used for "Auto-detect" (works fully offline).
SCRIPTS = [
    ("ar", r"[؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿]"),
    ("fa", None),  # Persian shares Arabic script; only used if 'ar' missing
    ("he", r"[֐-׿]"),
    ("ru", r"[Ѐ-ӿ]"),
    ("el", r"[Ͱ-Ͽ]"),
    ("hi", r"[ऀ-ॿ]"),
    ("ja", r"[぀-ヿ]"),
    ("ko", r"[가-힯]"),
    ("zh", r"[一-鿿]"),
    ("th", r"[฀-๿]"),
]


def installed_codes():
    return {l.code for l in argos_tr.get_installed_languages()}


def detect(text, installed):
    """Guess the source language from the writing system."""
    counts = {}
    for code, pattern in SCRIPTS:
        if pattern:
            n = len(re.findall(pattern, text))
            if n:
                counts[code] = n
    if counts:
        best = max(counts, key=counts.get)
        if best == "ar" and "ar" not in installed and "fa" in installed:
            best = "fa"
        if best in installed:
            return best
    # Latin script (or unknown): English if available
    if "en" in installed:
        return "en"
    return next(iter(sorted(installed)), None)


def state():
    langs = argos_tr.get_installed_languages()
    pairs = [
        {"from": p.from_code, "to": p.to_code, "from_name": p.from_name, "to_name": p.to_name}
        for p in argos_pkg.get_installed_packages()
        if getattr(p, "type", "translate") == "translate"
    ]
    return {
        "languages": sorted(({"code": l.code, "name": l.name} for l in langs), key=lambda x: x["name"]),
        "pairs": sorted(pairs, key=lambda x: (x["from_name"], x["to_name"])),
    }


def translate(text, source, target):
    installed = installed_codes()
    if not installed:
        raise ValueError("No languages installed yet. Click 'Languages' to add some.")
    if source == "auto":
        source = detect(text, installed)
        # Auto-detected the same language as the target? Flip to the other side.
        if source == target:
            others = [c for c in ("en", "ar") if c in installed and c != source]
            target = others[0] if others else target
    if source not in installed or target not in installed:
        raise ValueError(f"Language not installed: {source if source not in installed else target}")
    with LOCK:
        translation = argos_tr.get_translation_from_codes(source, target)
        if translation is None:
            raise ValueError("No model connects these two languages. Add one in 'Languages'.")
        result = translation.translate(text)
    return {"translation": result, "source": source, "target": target}


def available_packages():
    with LOCK:
        argos_pkg.update_package_index()  # needs internet
        pkgs = argos_pkg.get_available_packages()
    have = {(p.from_code, p.to_code) for p in argos_pkg.get_installed_packages()}
    out = [
        {
            "from": p.from_code, "to": p.to_code,
            "from_name": p.from_name, "to_name": p.to_name,
            "installed": (p.from_code, p.to_code) in have,
        }
        for p in pkgs
        if getattr(p, "type", "translate") == "translate"
    ]
    return sorted(out, key=lambda x: (x["from_name"], x["to_name"]))


def install(src, dst):
    with LOCK:
        argos_pkg.update_package_index()
        match = [p for p in argos_pkg.get_available_packages()
                 if p.from_code == src and p.to_code == dst]
        if not match:
            raise ValueError(f"No package for {src} -> {dst}")
        argos_pkg.install_from_path(match[0].download())
    # Warm-up: loads the model once and caches any helper files, so it works offline later.
    translate("Hello. This is a test.", src, dst)
    return state()


def uninstall(src, dst):
    with LOCK:
        for p in argos_pkg.get_installed_packages():
            if p.from_code == src and p.to_code == dst:
                argos_pkg.uninstall(p)
    return state()


# ---------------------------------------------------------------- web server

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):  # keep the terminal clean
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        try:
            if self.path in ("/", "/index.html"):
                self._send(200, (HERE / "index.html").read_bytes(), "text/html; charset=utf-8")
            elif self.path == "/api/state":
                self._send(200, state())
            elif self.path == "/api/available":
                try:
                    self._send(200, {"packages": available_packages()})
                except Exception:
                    self._send(503, {"error": "Can't reach the language list. Connect to the internet to download new languages (translating stays offline)."})
            else:
                self._send(404, {"error": "not found"})
        except Exception as e:
            self._send(500, {"error": str(e)})

    def do_POST(self):
        try:
            b = self._body()
            if self.path == "/api/translate":
                text = (b.get("text") or "")
                if not text.strip():
                    return self._send(200, {"translation": "", "source": b.get("source"), "target": b.get("target")})
                self._send(200, translate(text, b.get("source", "auto"), b.get("target", "ar")))
            elif self.path == "/api/install":
                self._send(200, install(b["from"], b["to"]))
            elif self.path == "/api/uninstall":
                self._send(200, uninstall(b["from"], b["to"]))
            else:
                self._send(404, {"error": "not found"})
        except ValueError as e:
            self._send(400, {"error": str(e)})
        except Exception as e:
            self._send(500, {"error": f"{type(e).__name__}: {e}"})


def main():
    try:
        server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        print(f"Translator is already running -> opening {URL}")
        webbrowser.open(URL)
        return
    print(f"\n  Offline Translator running at {URL}")
    print("  Keep this window open while you use it. Press Ctrl+C to quit.\n")
    if "--no-browser" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(URL)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nBye.")


if __name__ == "__main__":
    main()
