"""Make Argos Translate truly offline.

Argos uses `stanza` to split sentences. By default stanza re-downloads `resources.json`
from GitHub every time a model loads, so translation fails with no internet.
This patch makes stanza use the local copy first, and only download if it's missing
(which happens once, during setup, while online).
"""
import stanza

_Orig = stanza.Pipeline


class OfflineFirstPipeline(_Orig):
    def __init__(self, *args, **kwargs):
        if "download_method" in kwargs:
            super().__init__(*args, **kwargs)
            return
        try:
            super().__init__(*args, download_method=None, **kwargs)  # local files only
        except Exception:
            # resources.json not cached yet -> fetch it once (needs internet)
            super().__init__(*args, download_method="reuse_resources", **kwargs)


if not getattr(stanza.Pipeline, "_offline_patched", False):
    OfflineFirstPipeline._offline_patched = True
    stanza.Pipeline = OfflineFirstPipeline
