#!/usr/bin/env python3
"""Download Argos Translate models (needs internet once).

Usage:  python setup_models.py en ar      -> installs en->ar and ar->en
        python setup_models.py en ar fr   -> installs every direction between them (through the list)
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import offline_patch  # noqa: F401,E402
import argostranslate.package as pkg  # noqa: E402
import argostranslate.translate as tr

codes = sys.argv[1:] or ["en", "ar"]
print("Fetching language list...")
pkg.update_package_index()
available = pkg.get_available_packages()
installed = {(p.from_code, p.to_code) for p in pkg.get_installed_packages()}

wanted = {(a, b) for a in codes for b in codes if a != b}
for a, b in sorted(wanted):
    if (a, b) in installed:
        print(f"  {a} -> {b}: already installed")
        continue
    match = [p for p in available if p.from_code == a and p.to_code == b]
    if not match:
        print(f"  {a} -> {b}: no direct model (will bridge through English if possible)")
        continue
    print(f"  {a} -> {b}: downloading {match[0].from_name} -> {match[0].to_name} ...")
    for attempt in range(3):
        try:
            pkg.install_from_path(match[0].download())
            break
        except Exception as e:
            print(f"    attempt {attempt + 1} failed: {e}")
    else:
        print(f"  !! Could not download {a} -> {b}. Check internet, then re-run setup "
              f"or use the 'Languages' button in the app.")

# Warm-up: run each model once so any helper files get cached for offline use.
print("Preparing models for offline use...")
for p in pkg.get_installed_packages():
    try:
        out = tr.translate("Hello. This is a test.", p.from_code, p.to_code)
        print(f"  {p.from_code} -> {p.to_code}: OK  ({out[:40]})")
    except Exception as e:  # keep going; the app will show the error if it persists
        print(f"  {p.from_code} -> {p.to_code}: warm-up failed: {e}")
print("Translator models ready.")
