#!/bin/bash
# Starts the YouTube Downloader and opens it in your browser.
cd "$(dirname "$0")"
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
if [ ! -x .venv/bin/python ]; then
  echo "First run - doing setup first..."
  bash ./setup.command || { echo "Setup failed. See the messages above."; read -r -p "Press Enter to close."; exit 1; }
fi
# YouTube changes often - keep yt-dlp current (quick; skipped silently when offline).
echo "  Checking for yt-dlp updates..."
if command -v uv >/dev/null 2>&1; then
  uv pip install --python .venv/bin/python -U -q "yt-dlp[default,deno]" 2>/dev/null || true
else
  .venv/bin/python -m pip install -U -q "yt-dlp[default,deno]" 2>/dev/null || true
fi
export PATH="$PWD/.venv/bin:$PATH"
.venv/bin/python downloader/app.py
