#!/bin/bash
# One-time setup for Reda Tools (Offline Translator + YouTube Downloader).
# Double-click this file in Finder, or run:  bash setup.command
set -e
cd "$(dirname "$0")"
export PATH="$HOME/.local/bin:$HOME/.cargo/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

echo ""
echo "=== Reda Tools setup (takes ~3-6 minutes the first time) ==="

# 1) uv = fast Python installer/manager (installs Python 3.12 privately, doesn't touch system Python)
if ! command -v uv >/dev/null 2>&1; then
  echo "[1/5] Installing uv..."
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"
else
  echo "[1/5] uv found: $(command -v uv)"
fi

# 2) Private Python environment inside this folder (.venv)
if [ ! -x .venv/bin/python ]; then
  echo "[2/5] Creating Python 3.12 environment..."
  uv venv --seed --python 3.12 .venv
else
  echo "[2/5] Python environment exists"
fi

# 3) Libraries: Argos Translate (offline AI translation), yt-dlp (+deno JS runtime), static ffmpeg
echo "[3/5] Installing libraries (biggest step)..."
uv pip install --python .venv/bin/python -U argostranslate "yt-dlp[default,deno]" static-ffmpeg

# 4) Translation models (English <-> Arabic by default; add more from the app's Languages button)
echo "[4/5] Downloading translation models..."
.venv/bin/python translator/setup_models.py en ar

# 5) ffmpeg for the downloader
echo "[5/5] Checking ffmpeg..."
.venv/bin/python downloader/setup_ffmpeg.py

chmod +x ./*.command 2>/dev/null || true
echo ""
echo "=== All set! ==="
echo "Open  'Translator.command'  or  'YouTube Downloader.command'  to start."
echo ""
