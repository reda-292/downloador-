#!/bin/bash
# Starts the Offline Translator and opens it in your browser.
cd "$(dirname "$0")"
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
if [ ! -x .venv/bin/python ]; then
  echo "First run - doing setup first..."
  bash ./setup.command || { echo "Setup failed. See the messages above."; read -r -p "Press Enter to close."; exit 1; }
fi
export PATH="$PWD/.venv/bin:$PATH"
.venv/bin/python translator/app.py
