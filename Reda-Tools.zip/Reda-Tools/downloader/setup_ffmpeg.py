#!/usr/bin/env python3
"""Make sure ffmpeg + ffprobe are available (needed to merge video/audio and make MP3s)."""
import shutil

ff, fp = shutil.which("ffmpeg"), shutil.which("ffprobe")
if ff and fp:
    print(f"Using system ffmpeg: {ff}")
else:
    print("Downloading a private copy of ffmpeg (one time, ~70 MB)...")
    from static_ffmpeg import run
    ff, fp = run.get_or_fetch_platform_executables_else_raise()
    print(f"ffmpeg ready: {ff}")
