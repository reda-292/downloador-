#!/usr/bin/env python3
"""YouTube Downloader - a small local web app powered by yt-dlp.

Runs at http://127.0.0.1:8766 . Paste a link, pick MP4 (video) or MP3 (audio), download.
"""
import itertools
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import yt_dlp
from yt_dlp.utils import DownloadCancelled

HERE = Path(__file__).resolve().parent
PORT = int(os.environ.get("DOWNLOADER_PORT", "8766"))
URL = f"http://127.0.0.1:{PORT}"
SETTINGS_FILE = HERE / "settings.json"
MAX_PARALLEL = 2

# Make sure tools installed inside the app's Python environment (deno) are found.
os.environ["PATH"] = os.pathsep.join([str(Path(sys.executable).parent), "/opt/homebrew/bin", "/usr/local/bin",
                                      os.environ.get("PATH", "")])

ANSI = re.compile(r"\x1b\[[0-9;]*m")


# ---------------------------------------------------------------- tools

def find_ffmpeg():
    """None = use ffmpeg/ffprobe from PATH; otherwise the folder of the bundled static build."""
    if shutil.which("ffmpeg") and shutil.which("ffprobe"):
        return None
    try:
        from static_ffmpeg import run  # downloads once (~70 MB), then cached
        ff, _ = run.get_or_fetch_platform_executables_else_raise()
        return str(Path(ff).parent)
    except Exception as e:
        print(f"  WARNING: ffmpeg not available ({e}). MP3 conversion and HD video merging will fail.")
        return None


def js_runtime_args():
    """YouTube needs a JavaScript runtime. deno is installed with the app; node is a fallback."""
    args = []
    deno = shutil.which("deno")
    if deno:
        args += ["--js-runtimes", f"deno:{deno}"]
    node = shutil.which("node")
    if node:
        args += ["--js-runtimes", f"node:{node}"]
    return args


FFMPEG_DIR = None
JS_ARGS = js_runtime_args()


def load_settings():
    try:
        s = json.loads(SETTINGS_FILE.read_text())
    except Exception:
        s = {}
    s.setdefault("folder", str(Path.home() / "Downloads" / "YouTube Downloads"))
    return s


def save_settings(s):
    SETTINGS_FILE.write_text(json.dumps(s, indent=2, ensure_ascii=False))


SETTINGS = load_settings()


def open_path(path, reveal=False):
    path = str(path)
    if sys.platform == "darwin":
        subprocess.Popen(["open", "-R", path] if reveal else ["open", path])
    elif sys.platform.startswith("win"):
        subprocess.Popen(["explorer", "/select,", path] if reveal else ["explorer", path])
    else:
        subprocess.Popen(["xdg-open", path if not reveal else str(Path(path).parent)])


def clean(msg):
    msg = ANSI.sub("", str(msg)).replace("ERROR: ", "").strip()
    if "Sign in to confirm" in msg or "not a bot" in msg:
        msg += "\n→ YouTube is rate-limiting this connection. Wait a bit and try again."
    elif "Requested format is not available" in msg or "nsig" in msg or "Signature" in msg:
        msg += "\n→ Close the app and open it again (it updates itself), then retry."
    return msg


# ---------------------------------------------------------------- options

def build_argv(kind, quality, playlist, folder, tmp):
    # Each job works in its own temp folder, then moves the finished file into `folder`.
    argv = ["--color", "never", "--no-mtime", "-P", folder, "-P", f"temp:{tmp}", *JS_ARGS]
    if FFMPEG_DIR:
        argv += ["--ffmpeg-location", FFMPEG_DIR]
    if playlist:
        argv += ["--yes-playlist", "--ignore-errors",
                 "-o", "%(playlist_title).80B/%(playlist_index)03d - %(title).150B.%(ext)s"]
    else:
        argv += ["--no-playlist", "-o", "%(title).180B.%(ext)s"]

    if kind == "mp3":
        argv += ["-x", "--audio-format", "mp3", "--audio-quality", f"{int(quality)}K",
                 "--embed-metadata", "--embed-thumbnail"]
    else:
        if quality == "max":
            fmt = "bv*+ba[ext=m4a]/bv*+ba/b"
        else:
            h = f"[height<={int(quality)}]"
            # Prefer H.264 + AAC so the file plays everywhere (QuickTime, iPhone, WhatsApp...).
            fmt = f"bv*{h}[vcodec^=avc1]+ba[ext=m4a]/bv*{h}+ba[ext=m4a]/bv*{h}+ba/b{h}/b"
        argv += ["-f", fmt, "--merge-output-format", "mp4", "--embed-metadata"]
    return argv


# ---------------------------------------------------------------- jobs

JOBS = {}
JOBS_LOCK = threading.Lock()
SLOTS = threading.Semaphore(MAX_PARALLEL)
_ids = itertools.count(1)

PP_LABEL = {
    "Merger": "Merging video + audio…",
    "ExtractAudio": "Converting to MP3…",
    "FFmpegExtractAudio": "Converting to MP3…",
    "EmbedThumbnail": "Adding cover art…",
    "FFmpegMetadata": "Writing tags…",
    "Metadata": "Writing tags…",
    "MoveFiles": "Finishing…",
}


class JobLogger:
    def __init__(self, job):
        self.job = job

    def debug(self, msg):
        pass

    def info(self, msg):
        pass

    def warning(self, msg):
        pass

    def error(self, msg):
        self.job["errors"].append(clean(msg))


def run_job(job):
    def hook(d):
        if job["cancel"]:
            raise DownloadCancelled()
        info = d.get("info_dict") or {}
        job["title"] = info.get("title") or job["title"]
        idx = info.get("playlist_index")
        n = info.get("n_entries") or info.get("playlist_count")
        job["item"] = f"{idx} of {n}" if idx and n else ""
        if d["status"] == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            done = d.get("downloaded_bytes") or 0
            job.update(status="downloading",
                       percent=round(done * 100 / total, 1) if total else None,
                       speed=d.get("speed"), eta=d.get("eta"))
            is_audio_part = info.get("vcodec") == "none" and job["kind"] == "mp4"
            job["stage"] = "Downloading audio…" if is_audio_part else "Downloading…"
        elif d["status"] == "finished":
            job.update(percent=100, speed=None, eta=None, stage="Processing…")

    def pp_hook(d):
        if job["cancel"]:
            raise DownloadCancelled()
        if d["status"] == "started":
            job["stage"] = PP_LABEL.get(d.get("postprocessor"), "Processing…")
        elif d["status"] == "finished":
            fp = (d.get("info_dict") or {}).get("filepath")
            if fp:
                if tmp and fp.startswith(tmp):  # map temp path -> final path in the save folder
                    fp = str(Path(job["folder"]) / Path(fp).relative_to(tmp))
                job["file"] = fp

    job["status"] = "queued"
    job["stage"] = "Waiting…"
    with SLOTS:
        if job["cancel"]:
            job.update(status="cancelled", stage="Cancelled")
            return
        job.update(status="starting", stage="Getting video info…")
        tmp = None
        try:
            Path(job["folder"]).mkdir(parents=True, exist_ok=True)
            tmp = tempfile.mkdtemp(prefix="ytdl-")
            opts = yt_dlp.parse_options(build_argv(job["kind"], job["quality"], job["playlist"], job["folder"], tmp)).ydl_opts
            opts.update(progress_hooks=[hook], postprocessor_hooks=[pp_hook], logger=JobLogger(job),
                        quiet=True, noprogress=True)
            with yt_dlp.YoutubeDL(opts) as ydl:
                rc = ydl.download([job["url"]])
            if job["errors"] and job["playlist"]:
                job.update(status="done", stage=f"Done — {len(job['errors'])} item(s) failed", percent=100)
            elif rc and job["errors"]:
                job.update(status="error", stage="Failed", error=job["errors"][-1])
            else:
                job.update(status="done", stage="Done", percent=100)
        except DownloadCancelled:
            job.update(status="cancelled", stage="Cancelled", speed=None, eta=None)
        except Exception as e:  # DownloadError and anything unexpected
            if job["cancel"]:
                job.update(status="cancelled", stage="Cancelled", speed=None, eta=None)
            else:
                job.update(status="error", stage="Failed", speed=None, eta=None,
                           error=job["errors"][-1] if job["errors"] else clean(e))
        finally:
            if tmp:
                shutil.rmtree(tmp, ignore_errors=True)
        job["finished_at"] = time.time()


def add_job(url, kind, quality, playlist):
    jid = str(next(_ids))
    job = dict(id=jid, url=url, kind=kind, quality=quality, playlist=playlist, folder=SETTINGS["folder"],
               title=url, item="", status="queued", stage="Waiting…", percent=0, speed=None, eta=None,
               file=None, error=None, errors=[], cancel=False, created=time.time())
    with JOBS_LOCK:
        JOBS[jid] = job
    threading.Thread(target=run_job, args=(job,), daemon=True).start()
    return job


def public(job):
    return {k: v for k, v in job.items() if k not in ("errors", "cancel")}


def get_info(url, playlist):
    argv = ["--color", "never", "--skip-download", *JS_ARGS,
            "--yes-playlist" if playlist else "--no-playlist", "--flat-playlist"]
    opts = yt_dlp.parse_options(argv).ydl_opts
    opts.update(quiet=True, noprogress=True, logger=JobLogger({"errors": []}))
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    is_pl = info.get("_type") == "playlist"
    thumb = info.get("thumbnail")
    if not thumb and info.get("thumbnails"):
        thumb = info["thumbnails"][-1].get("url")
    if is_pl and not thumb:
        first = next(iter(info.get("entries") or []), None) or {}
        thumbs = first.get("thumbnails") or []
        thumb = thumbs[-1]["url"] if thumbs else None
    return {
        "title": info.get("title"),
        "channel": info.get("channel") or info.get("uploader"),
        "duration": info.get("duration"),
        "thumbnail": thumb,
        "playlist": is_pl,
        "count": (info.get("playlist_count") or len(list(info.get("entries") or []))) if is_pl else None,
    }


def choose_folder():
    if sys.platform != "darwin":
        raise ValueError("Type the folder path in the box instead.")
    r = subprocess.run(["osascript", "-e", 'POSIX path of (choose folder with prompt "Save downloads to:")'],
                       capture_output=True, text=True)
    path = r.stdout.strip()
    if not path:
        return None
    return path.rstrip("/")


# ---------------------------------------------------------------- web server

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            return self._send(200, (HERE / "index.html").read_bytes(), "text/html; charset=utf-8")
        if self.path == "/api/jobs":
            with JOBS_LOCK:
                jobs = sorted(JOBS.values(), key=lambda j: j["created"], reverse=True)
            return self._send(200, {"jobs": [public(j) for j in jobs], "folder": SETTINGS["folder"]})
        if self.path == "/api/settings":
            return self._send(200, SETTINGS)
        self._send(404, {"error": "not found"})

    def do_POST(self):
        try:
            b = self._body()
            p = self.path
            if p == "/api/download":
                urls = [u for u in re.split(r"\s+", b.get("url", "")) if u.startswith("http")]
                if not urls:
                    raise ValueError("Paste a YouTube link first.")
                kind = "mp3" if b.get("kind") == "mp3" else "mp4"
                quality = str(b.get("quality") or ("192" if kind == "mp3" else "1080"))
                jobs = [public(add_job(u, kind, quality, bool(b.get("playlist")))) for u in urls]
                return self._send(200, {"jobs": jobs})
            if p == "/api/info":
                try:
                    return self._send(200, get_info(b["url"].split()[0], bool(b.get("playlist"))))
                except Exception as e:
                    return self._send(400, {"error": clean(e)})
            if p == "/api/cancel":
                job = JOBS.get(str(b.get("id")))
                if job:
                    job["cancel"] = True
                    if job["status"] == "queued":
                        job.update(status="cancelled", stage="Cancelled")
                return self._send(200, {"ok": True})
            if p == "/api/clear":
                with JOBS_LOCK:
                    for jid in [k for k, j in JOBS.items() if j["status"] in ("done", "error", "cancelled")]:
                        del JOBS[jid]
                return self._send(200, {"ok": True})
            if p == "/api/open":
                job = JOBS.get(str(b.get("id"))) if b.get("id") else None
                if job and job.get("file") and Path(job["file"]).exists():
                    open_path(job["file"], reveal=True)
                else:
                    folder = Path(job["folder"] if job else SETTINGS["folder"])
                    folder.mkdir(parents=True, exist_ok=True)
                    open_path(folder)
                return self._send(200, {"ok": True})
            if p == "/api/folder":
                path = choose_folder() if b.get("choose") else (b.get("folder") or "").strip()
                if path:
                    path = str(Path(os.path.expanduser(path)))
                    Path(path).mkdir(parents=True, exist_ok=True)
                    SETTINGS["folder"] = path
                    save_settings(SETTINGS)
                return self._send(200, SETTINGS)
            self._send(404, {"error": "not found"})
        except ValueError as e:
            self._send(400, {"error": str(e)})
        except Exception as e:
            self._send(500, {"error": f"{type(e).__name__}: {e}"})


def main():
    global FFMPEG_DIR
    try:
        server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        print(f"Downloader is already running -> opening {URL}")
        webbrowser.open(URL)
        return
    print("  Checking ffmpeg…")
    FFMPEG_DIR = find_ffmpeg()
    if not JS_ARGS:
        print("  WARNING: no JavaScript runtime (deno/node) found - YouTube downloads may fail. Re-run setup.")
    print(f"\n  YouTube Downloader running at {URL}  (yt-dlp {yt_dlp.version.__version__})")
    print(f"  Saving to: {SETTINGS['folder']}")
    print("  Keep this window open while you use it. Press Ctrl+C to quit.\n")
    if "--no-browser" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(URL)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nBye.")


if __name__ == "__main__":
    main()
